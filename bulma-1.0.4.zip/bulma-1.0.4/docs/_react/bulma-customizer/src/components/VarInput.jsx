function VarInput() {}

export default VarInput;
