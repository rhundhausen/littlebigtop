---
title: "Bulma is on Patreon!"
layout: post
introduction: "Support Bulma's future"
color: "patreon"
name: "Bulma on Patreon"
icon: "patreon"
icon_brand: true
---

**Bulma** has now its own [Patreon page](https://www.patreon.com/jgthms):

<figure>
  <a href="https://www.patreon.com/jgthms" target="_blank">
    <img src="{{ site.url }}/images/blog/patreon-homepage.png" alt="Bulma Patreon homepage" width="840" height="525">
  </a>
</figure>

This will allow people to easily support Bulma, and ensure its future development.
